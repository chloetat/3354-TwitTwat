import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

class UploadPhotoTester {

    private UploadPhoto upload;

    @BeforeEach		// for junit testing
    void setUp() { 
    	//references the UploadPhoto class that is being tested, initializes with a fresh url
    	upload = new UploadPhoto("https://twittwat.com/api/upload-photo"); 
    }

    @Test
    void testUploadPhotoWithValidFile() throws IOException {
    	// tests UploadPhoto class's functionality when the file is valid
        File testFile = File.createTempFile("testPhoto", ".jpg");
        testFile.deleteOnExit();

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream(); // captures content in outputStream
        boolean result = upload.uploadPhoto(testFile, "(sample caption) Here is a photo of a bird I found on campus!", outputStream);

        assertTrue(result, "upload succeeds for a valid file"); // for junit testing, ensures success
        assertTrue(outputStream.size() > 0, "output contains upload data");
    }

    @Test
    void testUploadPhotoWithInvalidFile() { // testing exception handling, aka invalid file
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        boolean result = upload.uploadPhoto(null, "Sample caption", outputStream);

        assertFalse(result, "upload fails if file is invalid");
    }
    // we could also test for more instances like an empty caption, etc.
   
    }