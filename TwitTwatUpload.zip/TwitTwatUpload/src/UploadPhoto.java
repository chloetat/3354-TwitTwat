import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UploadPhoto {

    private static final Logger logger = Logger.getLogger(UploadPhoto.class.getName()); // object logger will allow for log of info/errors
    private static final String BOUNDARY = "---"; // string that will help distinguish different parts
    private static final String LINE_END = "\r\n"; // break for http
    private final String uploadUrl; 

    public UploadPhoto(String uploadUrl) { // points to endpoint which photo is uploaded
        this.uploadUrl = uploadUrl;
    }

    /**
     * uploadPhoto class uploads a photo file to the server
     * @param photo: photo file to upload
     * @param caption: caption for the photo
     * @param output: The output stream to simulate the upload (mostly just for testing)
     * @return true if upload was successful
     */
    public boolean uploadPhoto(File photo, String caption, OutputStream output) { // photo: the file, caption: caption, output: for output testing 
        if (photo == null || !photo.exists()) { // exception handling: if it doesnt exist then photo cant be uploaded
            logger.log(Level.SEVERE, "Invalid photo");
            return false;
        }

        try {
            addData(output, "photo", photo);	// photo to be processed
            addData(output, "caption", caption);	// caption written
            output.write((LINE_END + "--" + BOUNDARY + "--" + LINE_END).getBytes());
            return true;
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error occurred while uploading photo.", e); // if io exception occurs, there is an error, so return false
            return false;
        }
    }

    private void addData(OutputStream output, String name, Object value) throws IOException { // name:photo/caption, value:file/string fields
    	// this method is mainly used for testing by getting data and sending it to the output stream (when files are uploaded)
        output.write(("--" + BOUNDARY + LINE_END).getBytes()); // boundary separation
        if (value instanceof File) {
            File file = (File) value;
            output.write(("Content-Disposition: file-data; name=\"" + name + "\"; filename=\"" + file.getName() + "\"" + LINE_END).getBytes());
            // ^ info about the file
            output.write(("Content-Type: image/jpeg" + LINE_END + LINE_END).getBytes()); // types of files for photos

            try (FileInputStream inputStream = new FileInputStream(file)) { 
            	// file data handling... files read using FileInputStream and written to OutputStream
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    output.write(buffer, 0, bytesRead);
                }
            }
        } else { // if its a string, it is a caption and writes the string as the content to output
            output.write(("Content-Disposition: file-data; name=\"" + name + "\"" + LINE_END + LINE_END).getBytes());
            output.write(value.toString().getBytes());
        }
        output.write(LINE_END.getBytes()); 
    }
}