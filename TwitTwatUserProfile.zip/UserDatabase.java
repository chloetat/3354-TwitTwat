import java.util.*;

//A class to hold a list of users
public class UserDatabase {
    ArrayList<UserProfile> users = new ArrayList<UserProfile>();

    //A method to create a username based on username, id, and password
    public void createUser(String username, String password, int id) throws Exception {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getUsername().equals(username)) {
                throw new ClassCastException("Username taken");
            }
            if (users.get(i).getId() == id) {
                throw new ClassCastException("Id taken");
            }
        }

        UserProfile user = new UserProfile(username, password, id);
        users.add(user);
    }

    //Returns a user based on username but throws an error if no user exists
    public UserProfile getUser(String username) throws Exception {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getUsername().equals(username)) {
                return  users.get(i);
            }
        }
        throw new Exception("User doesn't exist");
    }

    //Returns a user based on id but throws an error if no user exists
    public UserProfile getUser(int id) throws Exception {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId() == id) {
                return  users.get(i);
            }
        }
        throw new Exception("User doesn't exist");
    }
}