//User Profile class that has a username, password, and id
public class UserProfile {
    private String username;
    private String password;
    private final int id;

    //Initialize
    public UserProfile(String username, String password, int id) {
        this.username = username;
        this.password = password;
        this.id = id;
    }

    ///Return variables
    public String getUsername() {
        return username;
    }

    //password is public for testing
    public String getPassword() {
        return password;
    }

    public int getId() {
        return id;
    }
}
