import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

///Test File to test UserProfile creation and the database which holds users
public class UserProfileTest {
    //Test UserProfile creation and that all the data stays consistent
    @Test
    public void testProfileCreation() {
        String username = "Zachary";
        String password = "Karanja";
        int id = 1;

        UserProfile user = new UserProfile(username, password, id);

        assertNotNull(user);
        assertEquals(user.getUsername(), username);
        assertEquals(user.getPassword(), password);
        assertEquals(user.getId(), id);
    }

    //Test UserDatabase creation to assert an object is actually created
    @Test
    public void testUserDatabaseCreation() throws Exception {
        UserDatabase users = new UserDatabase();

        String username = "Zachary";
        String password = "Karanja";
        int id = 1;

        users.createUser(username, password, id);

        assertNotNull(users);
    }

    //Tests that creating a user in the database with a duplicate username throws an error
    @Test
    public void testUserDatabaseDuplicateUsername() throws Exception {
        UserDatabase users = new UserDatabase();

        String username = "Zachary";
        String password = "Karanja";
        int id = 1;

        users.createUser(username, password, id);

        assertThrows(ClassCastException.class, () -> {users.createUser(password, username, id);}, "Username taken");
    }

    //Tests that creating a user in the database with a duplicate id throws an error
    @Test
    public void testUserDatabaseDuplicateId() throws Exception {
        UserDatabase users = new UserDatabase();

        String username = "Zachary";
        String password = "Karanja";
        int id = 1;

        users.createUser(username, password, id);

        assertThrows(ClassCastException.class, () -> {users.createUser(username, password, id+1);}, "Id taken");
    }

    //Tests searching for a user by username in the UserDatabase
    @Test
    public void testUserDatabaseSearchUsername() throws Exception {
        UserDatabase users = new UserDatabase();

        String username = "Zachary";
        String password = "Karanja";
        int id = 1;

        users.createUser(username, password, id);
        assertNotNull(users);

        UserProfile user = users.getUser(username);
        assertNotNull(user);
        assertEquals(user.getUsername(), username);
        assertEquals(user.getPassword(), password);
        assertEquals(user.getId(), id);
    }

    //Tests searching for a user by id in the UserDatabase
    @Test
    public void testUserDatabaseSearchId() throws Exception {
        UserDatabase users = new UserDatabase();

        String username = "Zachary";
        String password = "Karanja";
        int id = 1;

        users.createUser(username, password, id);
        assertNotNull(users);

        UserProfile user = users.getUser(id);
        assertNotNull(user);
        assertEquals(user.getUsername(), username);
        assertEquals(user.getPassword(), password);
        assertEquals(user.getId(), id);
    }

    //Tests searching for a user by username in the UserDatabase
    @Test
    public void testUserDatabaseSearchUsernameException() throws Exception {
        UserDatabase users = new UserDatabase();

        assertThrows(Exception.class, () -> {users.getUser("test");}, "User doesn't exist");
    }

    //Tests searching for a user by id in the UserDatabase
    @Test
    public void testUserDatabaseSearchIdException() throws Exception {
        UserDatabase users = new UserDatabase();

        assertThrows(Exception.class, () -> {users.getUser(0);}, "User doesn't exist");
    }
}