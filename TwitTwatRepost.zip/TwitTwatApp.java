
public class TwitTwatApp {
	//method to repost a photo
	public boolean repostPhoto(String userID, String photoID, String message) {
		if (userID == null || photoID == null || message == null) {
			return false;
		}
	
	//Assume here that the repost was sucessful
		System.out.println( "User " + userID + " reposted " + photoID + ": " + message);
		return true;
	}
}