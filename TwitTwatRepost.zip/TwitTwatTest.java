import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;


public class TwitTwatTest {
	private TwitTwatApp app;
	
@Before
	public void setUp() {
	app = new TwitTwatApp(); //Instantiate the app before test
}

@Test
	//Testing valid input for userID, photoID and message
	//input
		public void testRepostPhoto() {
		String userID = "john_135";
		String photoID = "photo_123";
		String message = "This is a nice photo!";
	
	//call the method
		boolean result = app.repostPhoto(userID, photoID, message);

		//verify that the repost was sucessful
		assertTrue(result);
	}

@Test
	//Testing invalid useID
	//input
		public void testInvalidUserID() {
		String userID = null;
		String photoID = "photo_123";
		String message = "This is a nice photo!";

	//call the method
		boolean result = app.repostPhoto(userID, photoID, message);

	//verify that the repost was not sucessful
	 assertFalse(result);
}

@Test
	//Testing invalid photoID
	//input
		public void testInvalidPhotoID() {
		String userID = "jane_123";
		String photoID = null;
		String message = "This is a nice photo";

	//call the method
		boolean result = app.repostPhoto(userID, photoID, message);

	//verify that the repost was not sucessful
		assertFalse(result);
}

@Test
	//Testing invalid photoID
	//input
		public void testInvalidMessage() {
		String userID = "jane_123";
		String photoID = "photo_246";
		String message = null;

	//call the method
		boolean result = app.repostPhoto(userID, photoID, message);

	//verify that the repost was not sucessful
		assertFalse(result);
}


}
